﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

        private void Dashboard_Load(object sender, EventArgs e)
        {
            string carsql = "select count(*)from Cartbl ";
            SqlDataAdapter sda=new SqlDataAdapter(carsql,con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            carlbl.Text = dt.Rows[0][0].ToString();

            string customersql = "select count(*)from Customertbl ";
            SqlDataAdapter sda1 = new SqlDataAdapter(customersql,con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            customerlbl.Text = dt1.Rows[0][0].ToString();

            string usersql = "select count(*)from Usertbl ";
            SqlDataAdapter sda2 = new SqlDataAdapter(usersql, con);
            DataTable dt2 = new DataTable();
            sda2.Fill(dt2);
            userlbl.Text = dt2.Rows[0][0].ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform mainform = new Mainform();
            mainform.Show();

        }

       
    }
}
