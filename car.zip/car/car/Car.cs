﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Car : Form
    {
        public Car()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = "select * from Cartbl";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            carDGV.DataSource = ds.Tables[0];
            con.Close();
        }


        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Car_Load(object sender, EventArgs e)
        {

            string sql = "select * from cartbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            carDGV.DataSource = dt;
            available.SelectedText = "Select";

            populate();
            


        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

            if (rno.Text == "" || brand.Text == "" || model.Text == "" || price.Text == "" || available.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con1.Open();
                    string query = "insert into Cartbl values('" + rno.Text + "','" + brand.Text + "','" + model.Text + "','" + available.SelectedItem.ToString() + "'," + price.Text + ")";
                    SqlCommand cmd = new SqlCommand(query, con1);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Add");
                    con1.Close();
                    populate();
                    rno.Text =brand.Text =model.Text = price.Text = available.Text =string.Empty;
                    rno.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }



        }

       

      

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
           
        }

       

        private void price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

       
       

        

       

       

        private void btnback_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
        }

   

       

        private void btnedit_Click_1(object sender, EventArgs e)
        {
            if (rno.Text == "" || brand.Text == "" || model.Text == "" || price.Text == "" || available.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Cartbl set Brand='" + brand.Text + "',Model='" + model.Text + "',Available='" + available.SelectedItem.ToString() + "',Price=" + price.Text + " where RegNum='" + rno.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Updated");
                    con.Close();
                    populate();
                    rno.Text = brand.Text = model.Text = price.Text = available.Text = string.Empty;
                    rno.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
            if (rno.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Cartbl where RegNum='" + rno.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record delete");
                    con.Close();
                    populate();
                    rno.Text = brand.Text = model.Text = price.Text = available.Text = string.Empty;
                    rno.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

        private void carDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.RowIndex;
            if (a > -1)
            {
                rno.Text = carDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                brand.Text = carDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                model.Text = carDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                available.SelectedItem = carDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                price.Text = carDGV.Rows[e.RowIndex].Cells[4].Value.ToString();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void search_SelectionChangeCommitted(object sender, EventArgs e)
        {
            String flag = "";
            if(search.SelectedItem.ToString()=="Available")
            {
                flag = "YES";
            }
            else
            {
                flag = "NO";
            }
            con.Open();
            String query = "select * from Cartbl where Available='"+flag+"'";
            SqlDataAdapter da=new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            carDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Yellow, ButtonBorderStyle.Inset);

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        
    }
}
