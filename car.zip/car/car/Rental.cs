﻿using Guna.UI2.Designer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Rental : Form
    {
        public Rental()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

        private void fillcombo()
        {
            con.Open();

            String query = "select  RegNum from Cartbl where Available='"+"Yes"+"'";
            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RegNum", typeof(string));
            dt.Load(rdr);
            carreg.ValueMember = "RegNum";
            carreg.DataSource = dt;
            con.Close();

        }
        private void fillCustomer()
        {
            con.Open();

            String query = "select  CustId from Customertbl";
            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CustId", typeof(int));
            dt.Load(rdr);
            custidcb.ValueMember = "CustId";
            custidcb.DataSource = dt;
            con.Close();

        }
        private void fetchCustName()
        {

            con.Open();
            String query= "select * from Customertbl where CustId=" +custidcb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query,con);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                custname.Text = dr["custname"].ToString();
            }
            con.Close();

          
        }
      
        private void populate()
        {
            con.Open();
            string query = "select * from Rentaltbl";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            rentDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void updateonRent()
        {
            con.Open();
            String query = "update Cartbl set Available='" + "No" + "' where RegNum='" + carreg.SelectedValue.ToString() + "';";
            SqlCommand cmd = new SqlCommand(query,con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        private void updateonRentDelete()
        {
            con.Open();
            String query = "update Cartbl set Available='" + "yes" + "' where RegNum='" + carreg.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query,con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        private void Rental_Load(object sender, EventArgs e)
        {
            string sql = "select * from Rentaltbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rentDGV.DataSource = dt;


            fillcombo();
            fillCustomer();
            
            populate();
         

        }


        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

            if (idtb.Text == "" || carreg.Text == " Select Carnumber " || custname.Text == "" || rentfee.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con1.Open();
                    string query = "insert into Rentaltbl values(" + idtb.Text + ",'" + carreg.SelectedValue.ToString() + "','" + custname.Text + "','" + rentdate.Text + "','"+returndate.Text+"','"+rentfee.Text+"')";
                    SqlCommand cmd = new SqlCommand(query, con1);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Inserted");
                    con1.Close();
                    updateonRent();
                    populate();
                    idtb.Text =custname.Text = rentfee.Text =string.Empty;
                    idtb.Focus();   
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }
       

      

      


        private void rentid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void custid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void rentfee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {

            if (idtb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Rentaltbl where RentId=" + idtb.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record delete");
                    con.Close();
                    populate();
                     updateonRentDelete();
                    idtb.Text = custname.Text = rentfee.Text = string.Empty;
                    idtb.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
           

        }

       
  
        private void custidcb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCustName();
        }

        private void rentdate_ValueChanged(object sender, EventArgs e)
        {
            returndate.MinDate = rentdate.Value;
        }

        private void rentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            idtb.Text = rentDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
            carreg.SelectedValue = rentDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            rentdate.Text = rentDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            returndate.Text = rentDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            rentfee.Text = rentDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

       
    }
}
