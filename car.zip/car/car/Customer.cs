﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = "select * from Customertbl";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            customerDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void Customer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carrentalDataSet19.Customertbl' table. You can move, or remove it, as needed.
            this.customertblTableAdapter1.Fill(this.carrentalDataSet19.Customertbl);
           populate();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (idtb.Text == "" || custnm.Text == "" || custadd.Text == "" || custphone.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Customertbl values(" + idtb.Text + ",'" + custnm.Text + "','" + custadd.Text + "','" + custphone.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Add");
                    con.Close();
                    populate();
                    idtb.Text = custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
            }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (idtb.Text == "" || custnm.Text == "" || custadd.Text == "" || custphone.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Customertbl set CustName='"+custnm.Text+"',CustAdd='"+custadd.Text+"',Phone='"+custphone.Text+"' where CustId="+idtb.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    populate();
                    idtb.Text = custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

            private void btndelete_Click(object sender, EventArgs e)
        {

            if (idtb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Customertbl where CustId=" + idtb.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Delete");
                    con.Close();
                    populate();
                    idtb.Text = custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
            
        }

        private void custid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void custphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
         
        }

      
        
    private void customerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            idtb.Text = customerDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
            custnm.Text = customerDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            custadd.Text = customerDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            custphone.Text = customerDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
    }
}
