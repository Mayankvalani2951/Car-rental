﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "select count(*) from  Usertbl where Uname='"+uname.Text+"' and Upass='"+upass.Text+"' ";
            SqlDataAdapter sda = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1")
            {
                Mainform mainform = new Mainform();
                mainform.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("wronng uname and upassword");
            }
            con.Close(); 
        }

        private void label4_Click(object sender, EventArgs e)
        {
            uname.Text = "";
            upass.Text = "";
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Yellow, ButtonBorderStyle.Inset);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void Login_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Rectangle rect = new Rectangle(uname.Location.X, uname.Location.Y, uname.ClientSize.Width, uname.ClientSize.Height);

            rect.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect1 = new Rectangle(upass.Location.X, upass.Location.Y, upass.ClientSize.Width, upass.ClientSize.Height);

            rect1.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect1, Color.Yellow, ButtonBorderStyle.Solid);

        }

        private void Login_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }
    }
}
