﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform mainform = new Mainform();
            mainform.Show();
        }
        private void fillcombo()
        {
            con.Open();

            String query = "select  RegNum from Cartbl where Available='" + "Yes" + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RegNum", typeof(string));
            dt.Load(rdr);
            billreg.ValueMember = "RegNum";
            billreg.DataSource = dt;
            con.Close();

        }
        private void fillCustomer()
        {
            con.Open();

            String query = "select  CustName from Customertbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CustName", typeof(String));
            dt.Load(rdr);
            billcustnm.ValueMember = "CustName";
            billcustnm.DataSource = dt;
            con.Close();

        }
        private void fetchCustphone()
        {

            con.Open();
            String query = "select * from Customertbl where CustName='" + billcustnm.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, con);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                billphone.Text = dr.ToString();
            }       
            con.Close();


        }
        private void Bill_Load(object sender, EventArgs e)
        {
            fillcombo();
            fillCustomer();
        }

        private void billcustnm_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCustphone();
        }

        private void preview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }
    }
}
