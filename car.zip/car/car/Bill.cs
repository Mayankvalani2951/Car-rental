﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform mainform = new Mainform();
            mainform.Show();
        }
        private void fillcombo()
        {
            con.Open();

            String query = "select  RegNum from Cartbl where Available='" + "No" +"'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RegNum", typeof(string));
            dt.Load(rdr);
            billreg.ValueMember = "RegNum";
            billreg.DataSource = dt;
            con.Close();

        }
             private void fillCustomer()
             {
                 con.Open();

                 String query = "select  CustName from Customertbl";
                 SqlCommand cmd = new SqlCommand(query, con);
                 SqlDataReader rdr;
                 rdr = cmd.ExecuteReader();
                 DataTable dt = new DataTable();
                 dt.Columns.Add("CustName", typeof(String));
                 dt.Load(rdr);
                 billcustnm.ValueMember = "CustName";
                 billcustnm.DataSource = dt;
                 con.Close();

             }
       
        private void fetchCustphone()
        {

            con.Open();
            String query = "select * from Customertbl where CustName='" + billcustnm.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, con);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                billphone.Text = dr["Phone"].ToString();
            }       
            con.Close();


        }
        private void fetchCardetail()
        {

            con.Open();
            String query = "select * from Cartbl where RegNum='" + billreg.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, con);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                brand.Text = dr["Brand"].ToString();
                model.Text = dr["Model"].ToString();
                price.Text = dr["Price"].ToString();
            }
            con.Close();


        }
        private void fetchCustNameR()
        {

            con.Open();
            String query = "select * from Rentaltbl where carReg='" + billreg.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, con);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                rentdate.Text = dr["Rentdate"].ToString();
                returndate.Text = dr["ReturnDate"].ToString();
                rentfee.Text = dr["RentFee"].ToString();
            }
            con.Close();


        }
        private void Bill_Load(object sender, EventArgs e)
        {
            fillcombo();
            fillCustomer();
        }

        private void billcustnm_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCustphone();
        }

        private void preview_Click(object sender, EventArgs e)
        {
           
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            
        }


        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string dashLine = "---------------------------------------------------------------------------------------------------------------------------------------------------";
           Bitmap bitmap = Properties.Resources.Web_Photo_Editor;
           Image img = bitmap;
           e.Graphics.DrawImage(img,4,4,820,230);
           
            e.Graphics.DrawString("Customer Name :"+ billcustnm.Text,new Font("Arial",11,FontStyle.Regular),Brushes.Black,new Point(25,300));
            e.Graphics.DrawString("Date :" + cdate.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(550, 300));
            e.Graphics.DrawString("Phone :" + billphone.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 330));
            e.Graphics.DrawString(dashLine, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 350));
            e.Graphics.DrawString("RegNum :" + billreg.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 375));
            e.Graphics.DrawString("Brand :" + brand.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 395));
            e.Graphics.DrawString("Model :" + model.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 415));
            e.Graphics.DrawString("Rent Date :" + rentdate.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 435));
            e.Graphics.DrawString("Return Date :" + returndate.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 455));
            e.Graphics.DrawString("Car Price :" + price.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(600, 375));
           
           
            e.Graphics.DrawString("Fee :" + rentfee.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(600, 425));
            e.Graphics.DrawString(dashLine, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 800));

            e.Graphics.DrawString("Total Amount :" ,new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 825));
            e.Graphics.DrawString("RS :" + total.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(600, 825));
            e.Graphics.DrawString(dashLine, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, new Point(25, 850));


        }

        private void billreg_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCardetail();
            fetchCustNameR();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Black, ButtonBorderStyle.Inset);
            
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Black, ButtonBorderStyle.Solid);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Black, ButtonBorderStyle.Solid);

        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void price_TextChanged(object sender, EventArgs e)
        {
            if(!price.Text.Equals("") && !rentfee.Text.Equals(""))
            {
                decimal totalprice=Convert.ToInt32(price.Text) + Convert.ToInt32(rentfee.Text);
                total.Text = totalprice.ToString();
            }
        }

        private void rentfee_TextChanged(object sender, EventArgs e)
        {
            if (!rentfee.Text.Equals("") && !price.Text.Equals(""))
            {
                decimal totalprice=Convert.ToInt32(price.Text) + Convert.ToInt32(rentfee.Text);
                total.Text= totalprice.ToString();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            

                printDocument1.Print();
           
        }
    }
}
