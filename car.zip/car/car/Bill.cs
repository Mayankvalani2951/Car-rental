﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform mainform = new Mainform();
            mainform.Show();
        }
     
        private void Bill_Load(object sender, EventArgs e)
        {
         

        }

        private void billreg_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
